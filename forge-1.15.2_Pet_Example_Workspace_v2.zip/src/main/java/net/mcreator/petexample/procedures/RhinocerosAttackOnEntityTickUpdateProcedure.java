package net.mcreator.petexample.procedures;

import net.minecraft.world.World;
import net.minecraft.entity.Entity;

import net.mcreator.petexample.entity.RhinocerosEntity;
import net.mcreator.petexample.PetexampleModElements;

@PetexampleModElements.ModElement.Tag
public class RhinocerosAttackOnEntityTickUpdateProcedure extends PetexampleModElements.ModElement {
	public RhinocerosAttackOnEntityTickUpdateProcedure(PetexampleModElements instance) {
		super(instance, 4);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure RhinocerosAttackOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure RhinocerosAttackOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure RhinocerosAttackOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure RhinocerosAttackOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure RhinocerosAttackOnEntityTickUpdate!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		entity.getPersistentData().putDouble("rhinocerousAttackTimer", ((entity.getPersistentData().getDouble("rhinocerousAttackTimer")) + 0.05));
		if (((entity.getPersistentData().getDouble("rhinocerousAttackTimer")) >= 30)) {
			if (!world.isRemote) {
				Entity entityToSpawn = new RhinocerosEntity.CustomEntity(RhinocerosEntity.entity, world);
				entityToSpawn.setLocationAndAngles(x, y, z, (float) (entity.rotationYaw), (float) (entity.rotationPitch));
				world.addEntity(entityToSpawn);
			}
			entity.remove();
		}
	}
}
