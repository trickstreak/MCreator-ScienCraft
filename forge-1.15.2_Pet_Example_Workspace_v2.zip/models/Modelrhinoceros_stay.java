// Made with Blockbench 3.5.2
// Exported for Minecraft version 1.15
// Paste this class into your mod and generate all required imports

public static class Modelrhinoceros_stay extends EntityModel<Entity> {
	private final ModelRenderer main;
	private final ModelRenderer head;
	private final ModelRenderer body;
	private final ModelRenderer rf_foot;
	private final ModelRenderer lf_foot;
	private final ModelRenderer rb_foot;
	private final ModelRenderer lb_foot;
	private final ModelRenderer tail;

	public Modelrhinoceros_stay() {
		textureWidth = 128;
		textureHeight = 128;

		main = new ModelRenderer(this);
		main.setRotationPoint(0.0F, 24.0F, 0.0F);

		head = new ModelRenderer(this);
		head.setRotationPoint(0.0F, -19.0F, -13.0F);
		main.addChild(head);
		setRotationAngle(head, 0.3491F, 0.0F, 0.0F);
		head.setTextureOffset(0, 44).addBox(-5.0F, -5.0F, -14.0F, 10.0F, 12.0F, 15.0F, 0.0F, false);
		head.setTextureOffset(0, 16).addBox(-1.5F, -9.7706F, -13.8939F, 3.0F, 4.0F, 3.0F, 0.0F, false);

		body = new ModelRenderer(this);
		body.setRotationPoint(0.0F, 0.0F, 0.0F);
		main.addChild(body);
		body.setTextureOffset(0, 0).addBox(-8.0F, -26.0F, -14.0F, 16.0F, 16.0F, 28.0F, 0.0F, false);

		rf_foot = new ModelRenderer(this);
		rf_foot.setRotationPoint(-5.0F, -10.0F, -11.0F);
		main.addChild(rf_foot);
		rf_foot.setTextureOffset(0, 0).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 10.0F, 6.0F, 0.0F, false);

		lf_foot = new ModelRenderer(this);
		lf_foot.setRotationPoint(5.0F, -10.0F, -11.0F);
		main.addChild(lf_foot);
		lf_foot.setTextureOffset(50, 50).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 10.0F, 6.0F, 0.0F, false);

		rb_foot = new ModelRenderer(this);
		rb_foot.setRotationPoint(-5.0F, -10.0F, 11.0F);
		main.addChild(rb_foot);
		rb_foot.setTextureOffset(44, 66).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 10.0F, 6.0F, 0.0F, false);

		lb_foot = new ModelRenderer(this);
		lb_foot.setRotationPoint(5.0F, -10.0F, 11.0F);
		main.addChild(lb_foot);
		lb_foot.setTextureOffset(60, 0).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 10.0F, 6.0F, 0.0F, false);

		tail = new ModelRenderer(this);
		tail.setRotationPoint(0.0F, -24.1206F, 13.316F);
		main.addChild(tail);
		setRotationAngle(tail, 0.3491F, 0.0F, 0.0F);
		tail.setTextureOffset(0, 44).addBox(-1.0F, 0.1206F, -1.0F, 2.0F, 11.0F, 2.0F, 0.0F, false);
	}

	@Override
	public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red,
			float green, float blue, float alpha) {
		main.render(matrixStack, buffer, packedLight, packedOverlay);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, e);
		this.head.rotateAngleY = f3 / (180F / (float) Math.PI);
		this.head.rotateAngleX = f4 / (180F / (float) Math.PI);
		this.rb_foot.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
		this.lb_foot.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
		this.rf_foot.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
		this.lf_foot.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
	}
}