// Paste this code into your mod.
// Make sure to generate all required imports

public static class Modelrhinoceros_wild extends ModelBase {
	private final ModelRenderer main;
	private final ModelRenderer head;
	private final ModelRenderer body;
	private final ModelRenderer rf_foot;
	private final ModelRenderer lf_foot;
	private final ModelRenderer rb_foot;
	private final ModelRenderer lb_foot;
	private final ModelRenderer tail;

	public Modelrhinoceros_wild() {
		textureWidth = 128;
		textureHeight = 128;

		main = new ModelRenderer(this);
		main.setRotationPoint(0.0F, 24.0F, 0.0F);

		head = new ModelRenderer(this);
		head.setRotationPoint(0.0F, -19.0F, -13.0F);
		setRotationAngle(head, 0.3491F, 0.0F, 0.0F);
		main.addChild(head);
		head.cubeList.add(new ModelBox(head, 0, 44, -5.0F, -5.0F, -14.0F, 10, 12, 15, 0.0F, false));
		head.cubeList.add(new ModelBox(head, 0, 16, -1.5F, -8.9866F, -13.8939F, 3, 4, 3, 0.0F, false));

		body = new ModelRenderer(this);
		body.setRotationPoint(0.0F, 0.0F, 0.0F);
		main.addChild(body);
		body.cubeList.add(new ModelBox(body, 0, 0, -8.0F, -26.0F, -14.0F, 16, 16, 28, 0.0F, false));

		rf_foot = new ModelRenderer(this);
		rf_foot.setRotationPoint(-5.0F, -10.0F, -11.0F);
		main.addChild(rf_foot);
		rf_foot.cubeList.add(new ModelBox(rf_foot, 0, 0, -3.0F, 0.0F, -3.0F, 6, 10, 6, 0.0F, false));

		lf_foot = new ModelRenderer(this);
		lf_foot.setRotationPoint(5.0F, -10.0F, -11.0F);
		main.addChild(lf_foot);
		lf_foot.cubeList.add(new ModelBox(lf_foot, 50, 50, -3.0F, 0.0F, -3.0F, 6, 10, 6, 0.0F, false));

		rb_foot = new ModelRenderer(this);
		rb_foot.setRotationPoint(-5.0F, -10.0F, 11.0F);
		main.addChild(rb_foot);
		rb_foot.cubeList.add(new ModelBox(rb_foot, 44, 66, -3.0F, 0.0F, -3.0F, 6, 10, 6, 0.0F, false));

		lb_foot = new ModelRenderer(this);
		lb_foot.setRotationPoint(5.0F, -10.0F, 11.0F);
		main.addChild(lb_foot);
		lb_foot.cubeList.add(new ModelBox(lb_foot, 60, 0, -3.0F, 0.0F, -3.0F, 6, 10, 6, 0.0F, false));

		tail = new ModelRenderer(this);
		tail.setRotationPoint(0.0F, -24.1206F, 13.316F);
		setRotationAngle(tail, 0.3491F, 0.0F, 0.0F);
		main.addChild(tail);
		tail.cubeList.add(new ModelBox(tail, 0, 44, -1.0F, 1.0F, -1.0F, 2, 11, 2, 0.0F, false));
	}

	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		main.render(f5);
	}
	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, e);
		this.head.rotateAngleY = f3 / (180F / (float) Math.PI);
		this.head.rotateAngleX = f4 / (180F / (float) Math.PI);
		this.rb_foot.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
		this.lb_foot.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
		this.rf_foot.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
		this.tail.rotateAngleZ = MathHelper.cos(f * 1.0F) * -1.0F * f1;
		this.lf_foot.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
	}
}