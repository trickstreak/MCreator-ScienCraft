package net.mcreator.carexample.procedures;

import net.minecraft.world.IWorld;
import net.minecraft.util.Direction;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.carexample.CarExampleModElements;
import net.mcreator.carexample.CarExampleMod;

import java.util.Map;

@CarExampleModElements.ModElement.Tag
public class TruckEntitiyHeathParticlesProcedure extends CarExampleModElements.ModElement {
	public TruckEntitiyHeathParticlesProcedure(CarExampleModElements instance) {
		super(instance, 9);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				CarExampleMod.LOGGER.warn("Failed to load dependency entity for procedure TruckEntitiyHeathParticles!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				CarExampleMod.LOGGER.warn("Failed to load dependency world for procedure TruckEntitiyHeathParticles!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		IWorld world = (IWorld) dependencies.get("world");
		double healthStage1 = 0;
		double healthStage2 = 0;
		double healthStage3 = 0;
		double posX = 0;
		double posY = 0;
		double posZ = 0;
		double random = 0;
		healthStage1 = (double) (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1) / 4);
		healthStage1 = (double) ((healthStage1) * 3);
		healthStage2 = (double) (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1) / 2);
		healthStage3 = (double) (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1) / 4);
		if (((entity.getHorizontalFacing()) == Direction.NORTH)) {
			if ((world.isRemote())) {
				posX = (double) (entity.getPosX());
				posY = (double) ((entity.getPosY()) + 1.5);
				posZ = (double) ((entity.getPosZ()) - 1.5);
				random = (double) Math.random();
				if ((((random) > 0.8) && ((random) <= 1))) {
					posX = (double) ((entity.getPosX()) + 0.5);
				} else if ((((random) > 0.6) && ((random) <= 0.8))) {
					posZ = (double) ((entity.getPosZ()) - 1);
				} else if ((((random) > 0.2) && ((random) <= 0.4))) {
					posZ = (double) ((entity.getPosZ()) - 2);
				} else if ((((random) >= 0) && ((random) <= 0.2))) {
					posX = (double) ((entity.getPosX()) - 0.5);
				}
			}
		} else if (((entity.getHorizontalFacing()) == Direction.EAST)) {
			if ((world.isRemote())) {
				posX = (double) ((entity.getPosX()) + 1.5);
				posY = (double) ((entity.getPosY()) + 1.5);
				posZ = (double) (entity.getPosZ());
				random = (double) Math.random();
				if ((((random) > 0.8) && ((random) <= 1))) {
					posX = (double) ((entity.getPosX()) + 2);
				} else if ((((random) > 0.6) && ((random) <= 0.8))) {
					posZ = (double) ((entity.getPosZ()) + 0.5);
				} else if ((((random) > 0.2) && ((random) <= 0.4))) {
					posZ = (double) ((entity.getPosZ()) - 0.5);
				} else if ((((random) >= 0) && ((random) <= 0.2))) {
					posX = (double) ((entity.getPosX()) + 1);
				}
			}
		} else if (((entity.getHorizontalFacing()) == Direction.SOUTH)) {
			if ((world.isRemote())) {
				posX = (double) (entity.getPosX());
				posY = (double) ((entity.getPosY()) + 1.5);
				posZ = (double) ((entity.getPosZ()) + 1.5);
				random = (double) Math.random();
				if ((((random) > 0.8) && ((random) <= 1))) {
					posX = (double) ((entity.getPosX()) + 0.5);
				} else if ((((random) > 0.6) && ((random) <= 0.8))) {
					posZ = (double) ((entity.getPosZ()) + 2);
				} else if ((((random) > 0.2) && ((random) <= 0.4))) {
					posZ = (double) ((entity.getPosZ()) + 1);
				} else if ((((random) >= 0) && ((random) <= 0.2))) {
					posX = (double) ((entity.getPosX()) - 0.5);
				}
			}
		} else if (((entity.getHorizontalFacing()) == Direction.WEST)) {
			if ((world.isRemote())) {
				posX = (double) ((entity.getPosX()) - 1.5);
				posY = (double) ((entity.getPosY()) + 1.5);
				posZ = (double) (entity.getPosZ());
				random = (double) Math.random();
				if ((((random) > 0.8) && ((random) <= 1))) {
					posX = (double) ((entity.getPosX()) - 1);
				} else if ((((random) > 0.6) && ((random) <= 0.8))) {
					posZ = (double) ((entity.getPosZ()) + 0.5);
				} else if ((((random) > 0.2) && ((random) <= 0.4))) {
					posZ = (double) ((entity.getPosZ()) - 0.5);
				} else if ((((random) >= 0) && ((random) <= 0.2))) {
					posX = (double) ((entity.getPosX()) - 2);
				}
			}
		}
		if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) > (healthStage2))
				&& (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) <= (healthStage1)))) {
			world.addParticle(ParticleTypes.SMOKE, (posX), (posY), (posZ), 0, 0.05, 0);
		} else if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) > (healthStage3))
				&& (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) <= (healthStage2)))) {
			world.addParticle(ParticleTypes.SMOKE, (posX), (posY), (posZ), 0, 0.05, 0);
			world.addParticle(ParticleTypes.FLAME, (posX), (posY), (posZ), 0, 0.03, 0);
		} else if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) > 0)
				&& (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) <= (healthStage3)))) {
			world.addParticle(ParticleTypes.SMOKE, (posX), (posY), (posZ), 0, 0.05, 0);
			world.addParticle(ParticleTypes.FLAME, (posX), (posY), (posZ), 0, 0.03, 0);
			world.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, (posX), (posY), (posZ), 0, 0.01, 0);
		}
	}
}
