package net.mcreator.carexample.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Hand;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.carexample.entity.TruckEntity;
import net.mcreator.carexample.entity.TruckChestTwoEntity;
import net.mcreator.carexample.entity.TruckChestOneEntity;
import net.mcreator.carexample.CarExampleModElements;
import net.mcreator.carexample.CarExampleMod;

import java.util.Map;
import java.util.HashMap;

@CarExampleModElements.ModElement.Tag
public class TruckRepairScriptProcedure extends CarExampleModElements.ModElement {
	public TruckRepairScriptProcedure(CarExampleModElements instance) {
		super(instance, 11);
		MinecraftForge.EVENT_BUS.register(this);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				CarExampleMod.LOGGER.warn("Failed to load dependency entity for procedure TruckRepairScript!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				CarExampleMod.LOGGER.warn("Failed to load dependency sourceentity for procedure TruckRepairScript!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				CarExampleMod.LOGGER.warn("Failed to load dependency world for procedure TruckRepairScript!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		Entity sourceentity = (Entity) dependencies.get("sourceentity");
		IWorld world = (IWorld) dependencies.get("world");
		double health = 0;
		double health2 = 0;
		double health3 = 0;
		double health4 = 0;
		if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) < ((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getMaxHealth()
				: -1))
				&& ((sourceentity.isSneaking())
						&& ((((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY)
								.getItem() == new ItemStack(Items.IRON_INGOT, (int) (1)).getItem())
								&& ((entity instanceof TruckEntity.CustomEntity) || ((entity instanceof TruckChestOneEntity.CustomEntity)
										|| (entity instanceof TruckChestTwoEntity.CustomEntity))))))) {
			if (dependencies.get("event") != null) {
				Object _obj = dependencies.get("event");
				if (_obj instanceof Event) {
					Event _evt = (Event) _obj;
					if (_evt.isCancelable())
						_evt.setCanceled(true);
				}
			}
			health = (double) (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1) / 5);
			health2 = (double) ((health) * 2);
			health3 = (double) ((health) * 3);
			health4 = (double) ((health) * 4);
			if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) > 0)
					&& (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) <= (health)))) {
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).setHealth((float) (health2));
			} else if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) > (health))
					&& (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) <= (health2)))) {
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).setHealth((float) (health3));
			} else if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) > (health2))
					&& (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) <= (health3)))) {
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).setHealth((float) (health4));
			} else if (((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) > (health3))
					&& (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) <= (health4)))) {
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).setHealth((float) ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1));
			}
			if (sourceentity instanceof LivingEntity) {
				ItemStack _setstack = ((sourceentity instanceof LivingEntity)
						? ((LivingEntity) sourceentity).getHeldItemMainhand()
						: ItemStack.EMPTY);
				_setstack.setCount(
						(int) (((((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY))
								.getCount()) - 1));
				((LivingEntity) sourceentity).setHeldItem(Hand.MAIN_HAND, _setstack);
				if (sourceentity instanceof ServerPlayerEntity)
					((ServerPlayerEntity) sourceentity).inventory.markDirty();
			}
			if ((!(world.isRemote()))) {
				if (world instanceof World && !world.isRemote()) {
					((World) world)
							.playSound(null, new BlockPos((int) (entity.getPosX()), (int) (entity.getPosY()), (int) (entity.getPosZ())),
									(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
											.getValue(new ResourceLocation("entity.villager.work_toolsmith")),
									SoundCategory.NEUTRAL, (float) 1, (float) 1);
				} else {
					((World) world).playSound((entity.getPosX()), (entity.getPosY()), (entity.getPosZ()),
							(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
									.getValue(new ResourceLocation("entity.villager.work_toolsmith")),
							SoundCategory.NEUTRAL, (float) 1, (float) 1, false);
				}
			}
		}
	}

	@SubscribeEvent
	public void onRightClickEntity(PlayerInteractEvent.EntityInteract event) {
		Entity entity = event.getTarget();
		PlayerEntity sourceentity = event.getPlayer();
		if (event.getHand() != sourceentity.getActiveHand()) {
			return;
		}
		double i = event.getPos().getX();
		double j = event.getPos().getY();
		double k = event.getPos().getZ();
		IWorld world = event.getWorld();
		Map<String, Object> dependencies = new HashMap<>();
		dependencies.put("x", i);
		dependencies.put("y", j);
		dependencies.put("z", k);
		dependencies.put("world", world);
		dependencies.put("entity", entity);
		dependencies.put("sourceentity", sourceentity);
		dependencies.put("event", event);
		this.executeProcedure(dependencies);
	}
}
